package com.example.guessx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Game extends AppCompatActivity {
    private int randomNum = (int)((Math.random() * (10 - 0)) + 0);
    private Button guessNumber;
    private int lives = 9;
    int streak = 0;
    private String strNum = String.valueOf(randomNum);;
    private String yes = "Correct";
    private String no = "Incorrect";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        ((TextView) findViewById(R.id.lifeCount)).setText(String.valueOf("Lives left:" + lives));
        ((TextView) findViewById(R.id.streak)).setText(String.valueOf("Streak" + streak));
        ((TextView) findViewById(R.id.temp)).setText(String.valueOf(strNum));
        guessNumber = (Button) findViewById(R.id.guessNum);
    }
    public void buttonClicked(View v){
        EditText input = (EditText) findViewById(R.id.guessInput);
        String wS = input.getText().toString();
        if(wS.equals(strNum)){
            ((TextView) findViewById(R.id.guess)).setText(yes);
            streak++;
            randomNum = (int)((Math.random() * (10 - 0)) + 0);
            strNum = String.valueOf(randomNum);
            ((TextView) findViewById(R.id.temp)).setText(String.valueOf(strNum));
        }
        else{
            ((TextView) findViewById(R.id.guess)).setText(no);
            lives--;
        }
        ((TextView) findViewById(R.id.lifeCount)).setText(String.valueOf("Lives left:" +lives));
        ((TextView) findViewById(R.id.streak)).setText(String.valueOf(streak));
        if(lives == 0){
            ((TextView) findViewById(R.id.lifeCount)).setText(no);
            guessNumber.setEnabled(false);
        }
    }
}