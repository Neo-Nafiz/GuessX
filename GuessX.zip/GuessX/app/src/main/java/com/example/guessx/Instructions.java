package com.example.guessx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Instructions extends AppCompatActivity {
    private String rules = "Welcome to GuessX! You will be guessing a number from a selected range and you will have 9 attempts to guess the correct number. The range will depend on the level of difficulty you choose. Easy is 1-10, Medium is 1-50, and Hard is 1- 100. We also have a custom range mode where you can decide the range you have to guess the number from. Your name and highest score will be displayed on the leaderboard. Have fun and remember you only have 9 lives!! ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);
        ((TextView) findViewById(R.id.instructionsText)).setText(rules);
    }
    public void instructionsStartClicked(View v){
        startActivity(new Intent(Instructions.this, Game.class));
    }

    public void backToMenuInstructions (View v) {
        startActivity(new Intent(Instructions.this, MainActivity.class));
    }
}