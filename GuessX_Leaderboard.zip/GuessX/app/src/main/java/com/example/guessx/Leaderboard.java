package com.example.guessx;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Leaderboard extends AppCompatActivity {

    ListView listView;
    ArrayList<String> userArray = new ArrayList<>();
    public void addUser(String user){
        userArray.add(user);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        listView =(ListView) findViewById(R.id.listview);

        ArrayList<String> arrayList = new ArrayList<>();

        arrayList.addAll(userArray);




        //arrayList.add(arrayList.inputUsername);
        /*
        arrayList.add("android");
        arrayList.add("is");
        arrayList.add("better");
        arrayList.add("than");
        arrayList.add("IOS");
        arrayList.add("andrasfdoid");
        arrayList.add("iafss");
        arrayList.add("betsfater");
        arrayList.add("thanfsa");
        arrayList.add("IOSsaf");
        arrayList.add("androfsaid");
        arrayList.add("isfsa");
        arrayList.add("bettfsaer");
        arrayList.add("thafsan");
        arrayList.add("IOsfaS");
        arrayList.add("andrsafoid");
        arrayList.add("isfas");
        arrayList.add("betfsater");
        arrayList.add("thafan");
        arrayList.add("IOsafdS");
        arrayList.add("androifsad");
        arrayList.add("ifass");
        arrayList.add("betfsater");
        arrayList.add("thafsan");
        arrayList.add("IOsafS");
        arrayList.add("andrfsaoid");
        arrayList.add("isgh");
        arrayList.add("bettkhger");
        arrayList.add("thagjn");
        arrayList.add("IgfOS");
        arrayList.add("andfhjroid");
        arrayList.add("ihgks");
        arrayList.add("bettkhger");
        arrayList.add("thgkhan");
        arrayList.add("IOkhgkhS");

         */

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);

    }
}