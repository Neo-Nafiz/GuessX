package com.example.guessx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Username extends AppCompatActivity {
    EditText inputUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username);

        /*Leaderboard newUser = new Leaderboard();
        inputUsername = (EditText) findViewById(R.id.username);
        String playerName = inputUsername.getText().toString();
        newUser.addUser(playerName);
         */

    }
    public void enterClicked(View v){
        startActivity(new Intent(Username.this, Difficulty.class));
        Leaderboard newUser = new Leaderboard();
        inputUsername = (EditText) findViewById(R.id.username);
        String playerName = inputUsername.getText().toString();
        newUser.addUser(playerName);

    }
    public void backToMenuInstructions (View v) {
        startActivity(new Intent(Username.this, MainActivity.class));
    }

}