package com.example.guessx;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Leaderboard extends AppCompatActivity {

    private Leaderboard adapterLeaderboard;

    ListView listView;
    ArrayList<String> userArray = new ArrayList<>();
    String userName = new String();
    String userStreak = new String();

    public void addStreak(String streak){
        this.userStreak = streak;
    }
    public void addUser(String user){
        this.userName = user;
    }
    String userPlusStreak = userName + userStreak + " points";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        listView =(ListView) findViewById(R.id.listview);

        ArrayList<String> arrayList = new ArrayList<>();

        arrayList.add("Test_User1 12 points");
        arrayList.add("Test_User2 3 points");
        arrayList.add("Test_User3 9 points");
        arrayList.add("Test_User4 18 points");
        arrayList.add(userPlusStreak);

        //arrayList.add(arrayList.inputUsername);
        /*
        arrayList.add("android");
        arrayList.add("is");
        arrayList.add("better");
        arrayList.add("than");
        arrayList.add("IOS");
        arrayList.add("andrasfdoid");
        arrayList.add("iafss");
        arrayList.add("betsfater");
        arrayList.add("thanfsa");
        arrayList.add("IOSsaf");
        arrayList.add("androfsaid");
        arrayList.add("isfsa");
        arrayList.add("bettfsaer");
        arrayList.add("thafsan");
        arrayList.add("IOsfaS");
        arrayList.add("andrsafoid");
        arrayList.add("isfas");
        arrayList.add("betfsater");
        arrayList.add("thafan");
        arrayList.add("IOsafdS");
        arrayList.add("androifsad");
        arrayList.add("ifass");
        arrayList.add("betfsater");
        arrayList.add("thafsan");
        arrayList.add("IOsafS");
        arrayList.add("andrfsaoid");
        arrayList.add("isgh");
        arrayList.add("bettkhger");
        arrayList.add("thagjn");
        arrayList.add("IgfOS");
        arrayList.add("andfhjroid");
        arrayList.add("ihgks");
        arrayList.add("bettkhger");
        arrayList.add("thgkhan");
        arrayList.add("IOkhgkhS");

         */

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
        //add listener to listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(Leaderboard.this,"clicked item:"+i+" "+arrayList.get(i).toString(), Toast.LENGTH_SHORT).show();
            }
        });
        ///adapterLeaderboard.notifyDataSetChanged();

    }
    public void backToMenuInstructions (View v) {
        startActivity(new Intent(Leaderboard.this, MainActivity.class));
    }



}