package com.example.guessx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PlayAgain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_again);
    }
    public void leaderBoardButtonClicked(View v){
        startActivity(new Intent(PlayAgain.this, Leaderboard.class));
    }
    public void playAgainButtonClicked(View v){
        startActivity(new Intent(PlayAgain.this, Game.class));
    }
    public void backToMenuInstructions (View v) {
        startActivity(new Intent(PlayAgain.this, MainActivity.class));
    }
}